# samzademo
Example samza application
count web log produced by kafka
